package com.dataviewer.musiclibrary;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import java.io.IOException;
import java.io.InputStream;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;


public class MusicLibraryController {
    public Label songsCount;
    private List<Song> songList = new ArrayList<>();

    public TextField songNameField;
    public ListView musicLibraryList;
    public Label clickSong;
    public ImageView musicLibraryLogo;

    public void initialize(){
        InputStream inputStream = getClass().getResourceAsStream("library.jpg");
        if (inputStream != null){
            Image svgImage = new Image(inputStream);
            musicLibraryLogo.setImage(svgImage);
        }
    }

    public SongDetails querySongDetails(String id) {
        String endpoint = "https://api.deezer.com/track/" + id;

        HttpClient client = HttpClient.newHttpClient();
        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(endpoint))
                .build();

        HttpResponse<String> response = null;
        try {
            response = client.send(request, HttpResponse.BodyHandlers.ofString());
        } catch (IOException | InterruptedException e) {
            throw new RuntimeException("Failed fetching song details with error: " + e);
        }
        Gson gson = new Gson();
        Type songDetailsType = new TypeToken<SongDetails>(){}.getType();
        return gson.fromJson(response.body(), songDetailsType);
    }

    public void queryMusic() {
        String query = songNameField.getText();
       String endpoint = "https://api.deezer.com/search?q=" + query.replace(" ", "");

        HttpClient client = HttpClient.newHttpClient();
        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(endpoint))
                .build();

        HttpResponse<String> response = null;
        try {
            response = client.send(request, HttpResponse.BodyHandlers.ofString());
        } catch (IOException | InterruptedException e) {
            throw new RuntimeException("Failed fetching music list with error: " + e);
        }
        Gson gson = new Gson();
        Type listResponseType = new TypeToken<ListResponse>(){}.getType();
        ListResponse listResponse = gson.fromJson(response.body(), listResponseType);
        ObservableList<String> songTitles = FXCollections.observableArrayList();

        for (Song song : listResponse.getData()) {
            songList.add(song);
            songTitles.add(song.getTitle());
        }
        clickSong.setVisible(!songTitles.isEmpty());
        songsCount.setText("Songs found: " + songTitles.size());
        musicLibraryList.setItems(songTitles);
    }

    public void viewSongDetails() {
        String selectedSong = (String) musicLibraryList.getSelectionModel().getSelectedItem();
        if (selectedSong != null) {
            for (Song song: this.songList){
                if(song.getTitle().equals(selectedSong)){
                    SongDetails songDetails = querySongDetails(song.getId());
                    Stage stage = (Stage) musicLibraryList.getScene().getWindow();
                    stage.setTitle("Song Details View");
                    ViewSwitcher<SongDetailsController> viewSwitcher = new ViewSwitcher<>(stage);
                    viewSwitcher.switchView("detailview.fxml");
                    SongDetailsController songDetailsController = viewSwitcher.getController();
                    songDetailsController.setSongArtwork(songDetails.getAlbum().getCoverBig());
                    songDetailsController.setSongTitle(songDetails.getTitle());
                    songDetailsController.setAlbumValue(songDetails.getAlbum().getTitle());
                    songDetailsController.setArtistValue(songDetails.getArtist().getName());
                    songDetailsController.setReleaseDate(songDetails.getReleaseDate());
                    songDetailsController.setExplicit(songDetails.isExplicitLyrics());
                    songDetailsController.setDuration(songDetails.getDuration() / 60 + " minutes");
                    songDetailsController.setPreviewURL(songDetails.getPreview());
                    StringBuilder contributors = new StringBuilder();
                    for(Contributor contributor: songDetails.getContributors()){
                        contributors.append(contributor.getName()).append("\n");
                    }
                    songDetailsController.setContributors(contributors.toString());
                    break;
                }
            }
        }
    }
}
