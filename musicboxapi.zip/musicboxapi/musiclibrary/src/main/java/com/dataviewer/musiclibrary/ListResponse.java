package com.dataviewer.musiclibrary;

import java.util.List;

public class ListResponse {
    public List<Song> data;

    public ListResponse(List<Song> d){
        this.data = d;
    }

    public List<Song> getData() {
        return data;
    }

    public void setData(List<Song> d) {
        this.data = d;
    }
}
