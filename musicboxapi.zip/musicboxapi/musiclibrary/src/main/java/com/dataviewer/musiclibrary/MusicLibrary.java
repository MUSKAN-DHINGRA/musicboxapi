package com.dataviewer.musiclibrary;

import javafx.application.Application;
import javafx.stage.Stage;

import java.io.IOException;

public class MusicLibrary extends Application {
    @Override
    public void start(Stage stage) throws IOException {
        stage.setTitle("Music Library");
        ViewSwitcher<MusicLibraryController> viewSwitcher = new ViewSwitcher<>(stage);
        viewSwitcher.switchView("listview.fxml");
    }

    public static void main(String[] args) {
        launch();
    }
}