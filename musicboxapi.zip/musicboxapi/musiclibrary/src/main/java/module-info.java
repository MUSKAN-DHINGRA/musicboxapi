module com.dataviewer.musiclibrary {
    requires javafx.controls;
    requires javafx.media;
    requires javafx.fxml;
    requires java.net.http;
    requires com.google.gson;


    opens com.dataviewer.musiclibrary to javafx.fxml;
    exports com.dataviewer.musiclibrary;
}